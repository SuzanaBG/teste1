import controllers.LoginController;

public class app {
    public static void main(String[] args) throws Exception {
        LoginController controller = new LoginController();
        controller.iniciar();
    }
}