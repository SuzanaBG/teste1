package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
    private static final String URL =
     "jdbc:mysql://localhost:3306/streaming?useSSL=false&serverTimezone=UTC"; //URL do banco de dados
    private static final String USER = "root"; //User do banco de dados
    private static final String PASSWORD = ""; //Pasword do banco de dados

    private static Connection connection = null; //Criação da variável que receberá a conexão com o banco de dados

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver"); //Chama o conector de java com MySQL
                connection = DriverManager.getConnection(URL, USER, PASSWORD); //Passa a URL, o user e o pasword do banco de dados
            } catch (Exception e) {
                System.out.println("Driver do MySQL não encontrado");
                System.out.println(e.getMessage());
                e.printStackTrace();
            }
        }
        return connection; //Retorna a conexão
    }

    public static void disconnect(Connection connection) {
        try {
            connection.close(); //Interrompe a conexão com o banco de dados
        } catch (SQLException e) {
            throw new RuntimeException("Error disconnecting from the database", e);
        }
    }
}
