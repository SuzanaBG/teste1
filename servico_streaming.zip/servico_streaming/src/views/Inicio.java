package views;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import controllers.FilmesController;
import controllers.SeriesController;
import controllers.UsuariosController;

public class Inicio extends JFrame{
    private JLabel tituloLabel;
    private JButton btFilmes, btSeries, btUsuarios;
    private JPanel panel1, panel2, panel2_1, panel2_2, panel2_3;

    public Inicio(){
        super("Início");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        tituloLabel = new JLabel("INÍCIO"); 
        btFilmes = new JButton("Filmes");
        btSeries = new JButton("Séries");
        btUsuarios = new JButton("Usuários");
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel2_1 = new JPanel();
        panel2_2 = new JPanel();
        panel2_3 = new JPanel();

        tituloLabel.setFont(new Font("Arial", Font.PLAIN, 20));

        btFilmes.addActionListener((actionEvent) -> acao(actionEvent));
        btSeries.addActionListener((actionEvent) -> acao(actionEvent));
        btUsuarios.addActionListener((actionEvent) -> acao(actionEvent));

        Container janela = getContentPane();
        janela.setLayout(new BorderLayout());

        panel1.setLayout(new FlowLayout());
        panel2.setLayout(new GridLayout(1, 3));
        panel2_1.setLayout(new FlowLayout());
        panel2_2.setLayout(new FlowLayout());
        panel2_3.setLayout(new FlowLayout());

        panel1.add(tituloLabel);

        panel2_1.add(btFilmes);
        panel2_2.add(btUsuarios);
        panel2_3.add(btSeries);

        panel2.add(panel2_1);
        panel2.add(panel2_2);
        panel2.add(panel2_3);

        janela.add(panel1, BorderLayout.NORTH);
        janela.add(panel2, BorderLayout.CENTER);
        pack();
    }
    public void acao(ActionEvent e){
        if (e.getSource() == btFilmes){
            FilmesController controller = new FilmesController();
            controller.iniciar();
        }
        if (e.getSource() == btSeries){
            SeriesController controller = new SeriesController();
            controller.iniciar();
        }
        if (e.getSource() == btUsuarios){
            UsuariosController controller = new UsuariosController();
            controller.iniciar();
        }
    }
}