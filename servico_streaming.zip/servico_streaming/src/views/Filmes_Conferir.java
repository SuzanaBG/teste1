package views;

import models.Filmes;
import controllers.FilmesController;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class Filmes_Conferir extends JFrame {
    private JLabel tituloLabel;
    private JTable table;
    private DefaultTableModel tableModel;
    private JPanel panel1, panel2, panel3, panel3_1, panel3_2, panel3_3;
    private JButton adicionarButton, editarButton, deletarButton;
    private FilmesController controller; 

    public Filmes_Conferir(FilmesController controller) {
        super("Filmes-Conferir");
        this.controller = controller; //Chama o controller
        initializeComponents(); //Chama a função initializeXomponents()
    }

    public void initializeComponents() {
        String[] columnNames = {"Código", "Nome", "Duração", "Gênero"};
        tituloLabel = new JLabel("FILMES");
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        panel3_1 = new JPanel();
        panel3_2 = new JPanel();
        panel3_3 = new JPanel();
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        adicionarButton = new JButton("Adicionar");
        editarButton = new JButton("Editar");
        deletarButton = new JButton("Deletar");

        tituloLabel.setFont(new Font("Arial", Font.PLAIN, 20));

        adicionarButton.addActionListener(e -> controller.adicionarFilme());
        editarButton.addActionListener(e -> controller.editarFilme());
        deletarButton.addActionListener(e -> controller.deletarFilme());

        this.setLayout(new BorderLayout());

        panel1.setLayout(new FlowLayout());
        panel2.setLayout(new FlowLayout());
        panel3.setLayout(new GridLayout(1, 3));
        panel3_1.setLayout(new FlowLayout());
        panel3_2.setLayout(new FlowLayout());
        panel3_3.setLayout(new FlowLayout());

        panel1.add(tituloLabel);
        panel2.add(scrollPane);

        panel3_1.add(adicionarButton);
        panel3_2.add(editarButton);
        panel3_3.add(deletarButton);

        panel3.add(panel3_1);
        panel3.add(panel3_2);
        panel3.add(panel3_3);

        this.add(panel1, BorderLayout.NORTH);
        this.add(panel2, BorderLayout.CENTER);
        this.add(panel3, BorderLayout.SOUTH);
        this.pack();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
    }

    public void atualizarTabela(List<Filmes> filmes) {
        tableModel.setRowCount(0); //Limpa a tabela com as informações antigas
        for (Filmes filme : filmes) {
            tableModel.addRow(new Object[]{
                filme.getCodigo(),
                filme.getNome(),
                filme.getDuracao(),
                filme.getGenero()
            }); //Adiciona as informações atualizadas à tabela
        }
    }

    public int getSelectedFilmeCodigo() {
        int selectedRow = table.getSelectedRow(); //Guarda a linha da tabela selecionada
        if (selectedRow != -1) {
            return (int) tableModel.getValueAt(selectedRow, 0); //Obtem o valor da primeira coluna da tabela
        }
        return -1;
    }
}