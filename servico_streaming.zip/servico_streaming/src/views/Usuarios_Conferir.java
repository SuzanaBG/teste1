//Idem ao Filmes_Conferir

package views;

import models.Usuarios;
import controllers.UsuariosController;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class Usuarios_Conferir extends JFrame{
    private JLabel tituloLabel;
    private JTable table;
    private DefaultTableModel tableModel;
    private JPanel panel1, panel2, panel3, panel3_1, panel3_2, panel3_3;
    private JButton adicionarButton, editarButton, deletarButton;
    private UsuariosController controller;

    public Usuarios_Conferir(UsuariosController controller) {
        super("Usuarios-Conferir");
        this.controller = controller;
        initializeComponents();
    }

    public void initializeComponents(){
        String [] colunas = {"Usuário", "Senha", "Quantidade de Perfils"};
        tituloLabel = new JLabel("USUÁRIOS");
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        panel3_1 = new JPanel();
        panel3_2 = new JPanel();
        panel3_3 = new JPanel();
        tableModel = new DefaultTableModel(colunas, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        adicionarButton = new JButton("Adicionar");
        editarButton = new JButton("Editar");
        deletarButton = new JButton("Deletar");

        tituloLabel.setFont(new Font("Arial", Font.PLAIN, 20));

        adicionarButton.addActionListener(e -> controller.adicionarUsuario());
        editarButton.addActionListener(e -> controller.editarUsuario());
        deletarButton.addActionListener(e -> controller.deletarUsuario());

        this.setLayout(new BorderLayout());

        panel1.setLayout(new FlowLayout());
        panel2.setLayout(new FlowLayout());
        panel3.setLayout(new GridLayout(1, 3));
        panel3_1.setLayout(new FlowLayout());
        panel3_2.setLayout(new FlowLayout());
        panel3_3.setLayout(new FlowLayout());

        panel1.add(tituloLabel);
        panel2.add(scrollPane);

        panel3_1.add(adicionarButton);
        panel3_2.add(editarButton);
        panel3_3.add(deletarButton);

        panel3.add(panel3_1);
        panel3.add(panel3_2);
        panel3.add(panel3_3);

        this.add(panel1, BorderLayout.NORTH);
        this.add(panel2, BorderLayout.CENTER);
        this.add(panel3, BorderLayout.SOUTH);
        this.pack();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
    }
    public void atualizarTabela(List<Usuarios> usuarios) {
        tableModel.setRowCount(0); 
        for (Usuarios usuario : usuarios) {
            tableModel.addRow(new Object[]{
                usuario.getUsuario(),
                usuario.getSenha(),
                usuario.getPerfil()
            });
        }
    }

    public String getSelectedUsuario() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            return tableModel.getValueAt(selectedRow, 0).toString();
        }
        return "";
    }
}