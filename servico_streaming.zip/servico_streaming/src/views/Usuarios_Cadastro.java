package views;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import models.Usuarios;
import views.Usuarios_Conferir;
import repository.UsuariosRepository;

public class Usuarios_Cadastro extends JDialog{
    private JLabel tituloLabel, usuarioLabel, senhaLabel, perfilsLabel;
    private JTextField usuarioTF, senhaTF;
    private JComboBox<String> perfilsCB;
    private JButton btInserir, btCancelar;
    private JPanel panel1, panel2, panel2_1, panel2_2, panel2_3, panel2_31, panel2_32;

    private Usuarios usuarios;
    private boolean isEditMode;

    public Usuarios_Cadastro(Frame parent, String title) {
        super(parent, title, true);
        this.isEditMode = false;
        initializeComponents();
    }

    public Usuarios_Cadastro(Frame parent, String title, Usuarios usuarios) {
        super(parent, title, true);
        this.usuarios = usuarios;
        this.isEditMode = true;
        initializeComponents();
        preencherCampos();
    }

    public void initializeComponents(){
        tituloLabel = new JLabel("USUÁRIOS");
        usuarioLabel = new JLabel("Usuário: ");
        senhaLabel = new JLabel("Senha: ");
        perfilsLabel = new JLabel("Qtd perfils: ");
        usuarioTF = new JTextField();
        senhaTF = new JTextField();
        btCancelar = new JButton("Cancelar");
        btInserir = new JButton("Inserir");
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel2_1 = new JPanel();
        panel2_2 = new JPanel();
        panel2_3 = new JPanel();
        panel2_31 = new JPanel();
        panel2_32 = new JPanel();

        perfilsCB = new JComboBox<>(new String []{ "1", "2", "3", "4", "5" });

        tituloLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        usuarioLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        senhaLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        perfilsLabel.setFont(new Font("Arial", Font.PLAIN, 16));

        usuarioTF.setPreferredSize(new Dimension(100, 16));
        senhaTF.setPreferredSize(new Dimension(100, 16));
        perfilsCB.setPreferredSize(new Dimension(100, 16));

        btInserir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validarCampos()) {
                    if (isEditMode) {
                        atualizarUsuario();
                    } else {
                        adicionarUsuario();
                    }
                    dispose();
                }
            }
        });

        btCancelar.addActionListener(e -> dispose());

        this.setLayout(new BorderLayout());

        panel1.setLayout(new FlowLayout());
        panel2.setLayout(new GridLayout(1, 3));
        panel2_1.setLayout(new GridLayout(3, 1));
        panel2_2.setLayout(new GridLayout(3, 1));
        panel2_3.setLayout(new GridLayout(2, 1));
        panel2_31.setLayout(new FlowLayout());
        panel2_32.setLayout(new FlowLayout());

        panel1.add(tituloLabel);

        panel2_31.add(btInserir);
        panel2_32.add(btCancelar);

        panel2_1.add(usuarioLabel);
        panel2_1.add(senhaLabel);
        panel2_1.add(perfilsLabel);

        panel2_2.add(usuarioTF);
        panel2_2.add(senhaTF);
        panel2_2.add(perfilsCB);

        panel2_3.add(panel2_31);
        panel2_3.add(panel2_32);

        panel2.add(panel2_1);
        panel2.add(panel2_2);
        panel2.add(panel2_3);

        this.add(panel1, BorderLayout.NORTH);
        this.add(panel2, BorderLayout.CENTER);
        this.pack();
        this.setLocationRelativeTo(getParent());
    }

    private void preencherCampos() {
        if (usuarios != null) {
            usuarioTF.setText(usuarios.getUsuario());
            senhaTF.setText(usuarios.getSenha());
            perfilsCB.setSelectedItem(String.valueOf(usuarios.getPerfil()));
        }
    }

    private boolean validarCampos() {
        String perfil = (String) perfilsCB.getSelectedItem();
        if (perfil == null ||
            usuarioTF.getText().trim().isEmpty() ||
            senhaTF.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(
                    this,
                    "Todos os campos são obrigatórios.",
                    "Erro", JOptionPane.ERROR_MESSAGE);
                return false;
        }
        return true;
    }
    
    private void adicionarUsuario() {
        int perfil = Integer.parseInt((String) perfilsCB.getSelectedItem());
        usuarios = new Usuarios(
            usuarioTF.getText().trim(),
            senhaTF.getText().trim(),
            perfil
        );

        UsuariosRepository repository = new UsuariosRepository();
        repository.adicionarUsuario(usuarios);
    }
    
    private void atualizarUsuario() {
        if (usuarios != null) {
            usuarios.setUsuario(usuarioTF.getText().trim());
            usuarios.setSenha(senhaTF.getText().trim());
            int perfil = Integer.parseInt((String) perfilsCB.getSelectedItem());
            usuarios.setPerfil(perfil);
        }

        UsuariosRepository repository = new UsuariosRepository();
        repository.atualizarUsuario(usuarios);
    }
    
    public Usuarios getUsuarios() {
        return usuarios;
    }
}