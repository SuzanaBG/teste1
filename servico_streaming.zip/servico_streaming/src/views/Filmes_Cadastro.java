package views;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import models.Filmes;
import views.Filmes_Conferir;
import repository.FilmesRepository;

public class Filmes_Cadastro extends JDialog{
    private JLabel tituloLabel, codigoLabel, nomeLabel, duracaoLabel, generoLabel;
    private JTextField codigoTF, nomeTF, duracaoTF;
    private JComboBox<String> generoCB;
    private JButton btInserir, btCancelar;
    private JPanel panel1, panel2, panel2_1, panel2_2, panel2_3, panel2_31, panel2_32;

    private Filmes filmes;
    private boolean isEditMode;

    public Filmes_Cadastro(Frame parent, String title) {
        super(parent, title, true);
        this.isEditMode = false;
        initializeComponents();
    }

    public Filmes_Cadastro(Frame parent, String title, Filmes filmes) {
        super(parent, title, true);
        this.filmes = filmes;
        this.isEditMode = true;
        initializeComponents();
        preencherCampos(); //Chama a função preencherCampos()
    }

    public void initializeComponents(){
        tituloLabel = new JLabel("FILMES");
        codigoLabel = new JLabel("Código: ");
        nomeLabel = new JLabel("Nome: ");
        duracaoLabel = new JLabel("Duração: ");
        generoLabel = new JLabel("Gênero: ");
        codigoTF = new JTextField();
        nomeTF = new JTextField();
        duracaoTF = new JTextField();
        btInserir = new JButton("Salvar");
        btCancelar = new JButton("Cancelar");
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel2_1 = new JPanel();
        panel2_2 = new JPanel();
        panel2_3 = new JPanel();
        panel2_31 = new JPanel();
        panel2_32 = new JPanel();

        generoCB = new JComboBox<>(new String[]{"Ação", "Comédia", "Drama", "Ficção", "Romance", "Terror/Suspense", "Documentário"});

        tituloLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        codigoLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        nomeLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        duracaoLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        generoLabel.setFont(new Font("Arial", Font.PLAIN, 16));

        codigoTF.setPreferredSize(new Dimension(100, 16));
        nomeTF.setPreferredSize(new Dimension(100, 16));
        duracaoTF.setPreferredSize(new Dimension(100, 16));
        generoCB.setPreferredSize(new Dimension(100, 16));

        btInserir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validarCampos()) {
                    if (isEditMode) {
                        atualizarFilme();
                    } else {
                        adicionarFilme();
                    }
                    dispose();
                }
            }
        });

        btCancelar.addActionListener(e -> dispose());

        this.setLayout(new BorderLayout());

        panel1.setLayout(new FlowLayout());
        panel2.setLayout(new GridLayout(1, 3));
        panel2_1.setLayout(new GridLayout(4, 1));
        panel2_2.setLayout(new GridLayout(4, 1));
        panel2_3.setLayout(new GridLayout(2, 1));
        panel2_31.setLayout(new FlowLayout());
        panel2_32.setLayout(new FlowLayout());

        panel1.add(tituloLabel);

        panel2_31.add(btInserir);
        panel2_32.add(btCancelar);

        panel2_1.add(codigoLabel);
        panel2_1.add(nomeLabel);
        panel2_1.add(duracaoLabel);
        panel2_1.add(generoLabel);

        panel2_2.add(codigoTF);
        panel2_2.add(nomeTF);
        panel2_2.add(duracaoTF);
        panel2_2.add(generoCB);

        panel2_3.add(panel2_31);
        panel2_3.add(panel2_32);

        panel2.add(panel2_1);
        panel2.add(panel2_2);
        panel2.add(panel2_3);

        this.add(panel1, BorderLayout.NORTH);
        this.add(panel2, BorderLayout.CENTER);
        this.pack();
        this.setLocationRelativeTo(getParent());
    }

    private void preencherCampos() {
        if (filmes != null) {
            codigoTF.setText(String.valueOf(filmes.getCodigo()));
            nomeTF.setText(filmes.getNome());
            duracaoTF.setText(String.valueOf(filmes.getDuracao()));
            generoCB.setSelectedItem(filmes.getGenero());
        } //Preenche os campos com as informações do filme selecionado para editar
    }

    private boolean validarCampos() {
        String genero = (String) generoCB.getSelectedItem();
        if (genero == null || genero.trim().isEmpty() ||
            codigoTF.getText().trim().isEmpty() ||
            nomeTF.getText().trim().isEmpty() ||
            duracaoTF.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(
                    this,
                    "Todos os campos são obrigatórios.",
                    "Erro", JOptionPane.ERROR_MESSAGE);
                return false;
        } //Verifica se todos os campos estão preenchidos corretamente
        return true;
    }
    
    private void adicionarFilme() {
        String genero = (String) generoCB.getSelectedItem();
        filmes = new Filmes(
            Integer.parseInt(codigoTF.getText().trim()),
            nomeTF.getText().trim(),
            Double.parseDouble(duracaoTF.getText().trim()),
            genero != null ? genero.trim() : ""
        ); //Guarda as informações inseridas

        FilmesRepository repository = new FilmesRepository();
        repository.adicionarFilme(filmes); //Passa as informações guardadas para a função adicionarFilme() no repository
    }
    
    private void atualizarFilme() {
        if (filmes != null) {
            filmes.setCodigo(Integer.parseInt(codigoTF.getText().trim()));
            filmes.setNome(nomeTF.getText().trim());
            filmes.setDuracao(Double.parseDouble(duracaoTF.getText().trim()));
            String genero = (String) generoCB.getSelectedItem();
            filmes.setGenero(genero != null ? genero.trim() : "");
        } //Passa as informações editadas para o model

        FilmesRepository repository = new FilmesRepository();
        repository.atualizarFilme(filmes); //Passa as informações para a função atualizarFilme() no repository
    }
    
    public Filmes getFilmes() {
        return filmes; //Retorna as informações inseridas
    }
}