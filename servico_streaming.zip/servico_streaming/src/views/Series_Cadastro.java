//Idem ao Filmes_Cadastro

package views;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

import models.Series;
import views.Series_Conferir;
import repository.SeriesRepository;

public class Series_Cadastro extends JDialog{
    private JLabel tituloLabel, codigoLabel, nomeLabel, duracaoLabel, qtdEpsLabel, qtdTempLabel, generoLabel;
    private JTextField codigoTF, nomeTF, duracaoTF, qtdEpsTF, qtdTempTF;
    private JComboBox<String> generoCB;
    private JButton btInserir, btCancelar;
    private JPanel panel1, panel2, panel2_1, panel2_2, panel2_3, panel2_31, panel2_32;

    private Series series;
    private boolean isEditMode;

    public Series_Cadastro(Frame parent, String title) {
        super(parent, title, true);
        this.isEditMode = false;
        initializeComponents();
    }

    public Series_Cadastro(Frame parent, String title, Series series) {
        super(parent, title, true);
        this.series = series;
        this.isEditMode = true;
        initializeComponents();
        preencherCampos();
    }

    public void initializeComponents(){
        tituloLabel = new JLabel("SÉRIES");
        codigoLabel = new JLabel("Código: ");
        nomeLabel = new JLabel("Nome: ");
        duracaoLabel = new JLabel("Duração: ");
        qtdEpsLabel = new JLabel("Qtd episódios: ");
        qtdTempLabel = new JLabel("Qtd temporadas: ");
        generoLabel = new JLabel("Gênero: ");
        codigoTF = new JTextField();
        nomeTF = new JTextField();
        duracaoTF = new JTextField();
        qtdEpsTF = new JTextField();
        qtdTempTF = new JTextField();
        btInserir = new JButton("Inserir");
        btCancelar = new JButton("Cancelar");
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel2_1 = new JPanel();
        panel2_2 = new JPanel();
        panel2_3 = new JPanel();
        panel2_31 = new JPanel();
        panel2_32 = new JPanel();

        generoCB = new JComboBox<>(new String[]{"Ação", "Comédia", "Drama", "Ficção", "Romance", "Terror/Suspense", "Documentário"});

        tituloLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        codigoLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        nomeLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        duracaoLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        qtdEpsLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        qtdTempLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        generoLabel.setFont(new Font("Arial", Font.PLAIN, 16));

        codigoTF.setPreferredSize(new Dimension(100, 16));
        nomeTF.setPreferredSize(new Dimension(100, 16));
        duracaoTF.setPreferredSize(new Dimension(100, 16));
        qtdEpsTF.setPreferredSize(new Dimension(100, 16));
        qtdTempTF.setPreferredSize(new Dimension(100, 16));
        generoCB.setPreferredSize(new Dimension(100, 16));

        btInserir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validarCampos()) {
                    if (isEditMode) {
                        atualizarSerie();
                    } else {
                        adicionarSerie();
                    }
                    dispose();
                }
            }
        });

        btCancelar.addActionListener(e -> dispose());

        this.setLayout(new BorderLayout());

        panel1.setLayout(new FlowLayout());
        panel2.setLayout(new GridLayout(1, 3));
        panel2_1.setLayout(new GridLayout(6, 1));
        panel2_2.setLayout(new GridLayout(6, 1));
        panel2_3.setLayout(new GridLayout(2, 1));
        panel2_31.setLayout(new FlowLayout());
        panel2_32.setLayout(new FlowLayout());

        panel1.add(tituloLabel);

        panel2_31.add(btInserir);
        panel2_32.add(btCancelar);

        panel2_1.add(codigoLabel);
        panel2_1.add(nomeLabel);
        panel2_1.add(duracaoLabel);
        panel2_1.add(qtdEpsLabel);
        panel2_1.add(qtdTempLabel);
        panel2_1.add(generoLabel);

        panel2_2.add(codigoTF);
        panel2_2.add(nomeTF);
        panel2_2.add(duracaoTF);
        panel2_2.add(qtdEpsTF);
        panel2_2.add(qtdTempTF);
        panel2_2.add(generoCB);

        panel2_3.add(panel2_31);
        panel2_3.add(panel2_32);

        panel2.add(panel2_1);
        panel2.add(panel2_2);
        panel2.add(panel2_3);

        this.add(panel1, BorderLayout.NORTH);
        this.add(panel2, BorderLayout.CENTER);
        this.pack();
        this.setLocationRelativeTo(getParent());
    }

    private void preencherCampos() {
        if (series != null) {
            codigoTF.setText(String.valueOf(series.getCodigo()));
            nomeTF.setText(series.getNome());
            duracaoTF.setText(String.valueOf(series.getDuracao()));
            qtdEpsTF.setText(String.valueOf(series.getQtdEp()));
            qtdTempTF.setText(String.valueOf(series.getQtdTemp()));
            generoCB.setSelectedItem(series.getGenero());
        }
    }

    private boolean validarCampos() {
        String genero = (String) generoCB.getSelectedItem();
        if (genero == null || genero.trim().isEmpty() ||
            codigoTF.getText().trim().isEmpty() ||
            nomeTF.getText().trim().isEmpty() ||
            duracaoTF.getText().trim().isEmpty() ||
            qtdEpsTF.getText().trim().isEmpty() ||
            qtdTempTF.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(
                    this,
                    "Todos os campos são obrigatórios.",
                    "Erro", JOptionPane.ERROR_MESSAGE);
                return false;
        }
        return true;
    }
    
    private void adicionarSerie() {
        String genero = (String) generoCB.getSelectedItem();
        series = new Series(
            Integer.parseInt(codigoTF.getText().trim()),
            nomeTF.getText().trim(),
            Double.parseDouble(duracaoTF.getText().trim()),
            Integer.parseInt(qtdEpsTF.getText().trim()),
            Integer.parseInt(qtdTempTF.getText().trim()),
            genero != null ? genero.trim() : ""
        );

        SeriesRepository repository = new SeriesRepository();
        repository.adicionarSerie(series);
    }
    
    private void atualizarSerie() {
        if (series != null) {
            series.setCodigo(Integer.parseInt(codigoTF.getText().trim()));
            series.setNome(nomeTF.getText().trim());
            series.setDuracao(Double.parseDouble(duracaoTF.getText().trim()));
            series.setQtdEp(Integer.parseInt(qtdEpsTF.getText().trim()));
            series.setQtdTemp(Integer.parseInt(qtdTempTF.getText().trim()));
            String genero = (String) generoCB.getSelectedItem();
            series.setGenero(genero != null ? genero.trim() : "");
        }

        SeriesRepository repository = new SeriesRepository();
        repository.atualizarSerie(series);
    }
    
    public Series getSeries() {
        return series;
    }
}