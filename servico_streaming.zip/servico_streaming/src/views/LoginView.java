package views;

import models.LoginModel;
import controllers.LoginController;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class LoginView extends JFrame{
    private JLabel tituloLabel, usuarioLabel, senhaLabel;
    private JTextField usuarioTF;
    private JPasswordField senhaPF;
    private JButton btLogin;
    private JPanel panel1, panel2, panel2_1, panel2_2, panel3;
    private LoginController controller;

    public LoginView(LoginController controller) {
        super("Login");
        this.controller = controller;
        initializeComponents();
    }

    public void initializeComponents(){
        tituloLabel = new JLabel("LOGIN");
        usuarioLabel = new JLabel("Usuário: ");
        senhaLabel = new JLabel("Senha: ");
        usuarioTF = new JTextField();
        senhaPF = new JPasswordField();
        btLogin = new JButton("Entrar");
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel2_1 = new JPanel();
        panel2_2 = new JPanel();
        panel3 = new JPanel();

        tituloLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        usuarioLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        senhaLabel.setFont(new Font("Arial", Font.PLAIN, 16));

        usuarioTF.setPreferredSize(new Dimension(100, 16));
        senhaPF.setPreferredSize(new Dimension(100, 16));

        btLogin.addActionListener((actionEvent) -> entrar(actionEvent));

        this.setLayout(new BorderLayout());

        panel1.setLayout(new FlowLayout());
        panel2.setLayout(new GridLayout(1, 2));
        panel2_1.setLayout(new GridLayout(2, 1));
        panel2_2.setLayout(new GridLayout(2, 1));
        panel3.setLayout(new FlowLayout());

        panel1.add(tituloLabel); 

        panel2_1.add(usuarioLabel); 
        panel2_1.add(senhaLabel);

        panel2_2.add(usuarioTF);
        panel2_2.add(senhaPF);

        panel2.add(panel2_1);
        panel2.add(panel2_2);

        panel3.add(btLogin);

        this.add(panel1, BorderLayout.NORTH);
        this.add(panel2, BorderLayout.CENTER);
        this.add(panel3, BorderLayout.SOUTH);
        this.pack();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
    }

    private void entrar(ActionEvent event) {
        try {
            String usuario = usuarioTF.getText();
            String senha = new String(senhaPF.getPassword());
    
            if (controller.tentarLogin(usuario, senha)) {
                JOptionPane.showMessageDialog(this, "Login bem-sucedido!");
            } else {
                JOptionPane.showMessageDialog(this, "Usuário ou senha inválidos.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Usuário deve ser um número.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    } //Chama a função tentarLogin() para verificar login
}