package repository;

import models.Series;
import config.DbConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SeriesRepository {
    public void adicionarSerie(Series series){
        String sql = "INSERT INTO series (codigo, nome, duracao, qtdEpisodios, qtdTemporadas, genero) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DbConnection.getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, series.getCodigo());
            stmt.setString(2, series.getNome());
            stmt.setDouble(3, series.getDuracao());
            stmt.setInt(4, series.getQtdEp());
            stmt.setInt(5, series.getQtdTemp());
            stmt.setString(6, series.getGenero());

            int linhasAfetadas = stmt.executeUpdate();
            if(linhasAfetadas > 0) {
                System.out.println("Serie adicionado com sucesso!");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao adicionar serie.");
            e.printStackTrace();
        }
    }

    public List<Series> obterTodosSeries() {
        List<Series> series = new ArrayList<>();
        String sql = "SELECT * FROM series";

        try (Connection conn = DbConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
                
                while (rs.next()) {
                    Series todosSeries = new Series(
                        rs.getInt("codigo"),
                        rs.getString("nome"),
                        rs.getDouble("duracao"),
                        rs.getInt("qtdEpisodios"),
                        rs.getInt("qtdTemporadas"),
                        rs.getString("genero")
                    );
                    series.add(todosSeries);
                }
             } catch (SQLException e) {
                System.out.println("Erro ao obter series.");
                e.printStackTrace();
             }

             return series;
    }

    public Series obterSeriePorCodigo(int codigo) {
        String sql = "SELECT * FROM series WHERE codigo = ?";
        Series series = null;

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, codigo);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    series = new Series(
                        rs.getInt("codigo"),
                        rs.getString("nome"),
                        rs.getDouble("duracao"),
                        rs.getInt("qtdEpisodios"),
                        rs.getInt("qtdTemporadas"),
                        rs.getString("genero")
                    );
                }
             } catch (SQLException e) {
                System.out.println("Erro ao obter serie por código.");
                e.printStackTrace();
             }

             return series;
    }

    public void atualizarSerie(Series series) {
        String sql = 
            "UPDATE series SET nome = ?, duracao = ?, qtdEpisodios = ?, qtdTemporadas = ?, genero = ? WHERE codigo = ?";

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, series.getNome());
                stmt.setDouble(2, series.getDuracao());
                stmt.setInt(3, series.getQtdEp());
                stmt.setInt(4, series.getQtdTemp());
                stmt.setString(5, series.getGenero());
                stmt.setInt(6, series.getCodigo());

                int linhasAfetadas = stmt.executeUpdate();
                if (linhasAfetadas > 0) {
                    System.out.println("Serie atualizado com sucesso!");
                } else {
                    System.out.println("Serie não encontrado.");
                }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar serie.");
            e.printStackTrace();
        }
    }

    public void deletarSerie(int codigo) {
        String sql = "DELETE FROM series WHERE codigo = ?";

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
                
                stmt.setInt(1, codigo);

                int linhasAfetadas = stmt.executeUpdate();
                if (linhasAfetadas > 0) {
                    System.out.println("Serie deletado com sucesso!");
                } else {
                    System.out.println("Serie não encontrado.");
                }
        } catch (SQLException e) {
            System.out.println("Erro ao deletar serie.");
            e.printStackTrace();
        }
    }
}