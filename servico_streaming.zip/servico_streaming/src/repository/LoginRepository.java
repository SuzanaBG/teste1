//Idem ao FilmesRepository

package repository;

import models.LoginModel;
import config.DbConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LoginRepository {
    public List<LoginModel> obterTodosLogins() throws SQLException {
        List<LoginModel> logins = new ArrayList<>();
        String sql = "SELECT * FROM login";
    
        try (Connection conn = DbConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
    
            while (rs.next()) {
                LoginModel login = new LoginModel(
                    rs.getInt("usuario"), 
                    rs.getString("senha")
                );
                logins.add(login);
            }
        }
        return logins;
    }        
}