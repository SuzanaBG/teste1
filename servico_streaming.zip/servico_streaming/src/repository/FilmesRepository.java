package repository;

import models.Filmes;
import config.DbConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FilmesRepository {
    public void adicionarFilme(Filmes filmes){
        String sql = "INSERT INTO filmes (codigo, nome, duracao, genero) VALUES (?, ?, ?, ?)"; //Comando SQL para inserir os valores no banco de dados

        try (Connection conn = DbConnection.getConnection(); //Chama a conexão com o banco de dados
        PreparedStatement stmt = conn.prepareStatement(sql)) { //Executa o comando SQL
            
            stmt.setInt(1, filmes.getCodigo());
            stmt.setString(2, filmes.getNome());
            stmt.setDouble(3, filmes.getDuracao());
            stmt.setString(4, filmes.getGenero()); //Inserir os valores puxados do model para o banco de dados

            int linhasAfetadas = stmt.executeUpdate(); //Número de linhas afetadas no banco de dados
            if(linhasAfetadas > 0) {
                System.out.println("Filme adicionado com sucesso!");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao adicionar filme.");
            e.printStackTrace();
        }
    }

    public List<Filmes> obterTodosFilmes() {
        List<Filmes> filmes = new ArrayList<>(); //Criando um ArrayList para receber todos os filmes do banco de dados
        String sql = "SELECT * FROM filmes"; //Comando SQL para buscar todos os filmes

        try (Connection conn = DbConnection.getConnection();
             Statement stmt = conn.createStatement(); //Cria uma variável para enviar o comando SQL ao banco de dados
             ResultSet rs = stmt.executeQuery(sql)) { //Executa o comando SQL
                
                while (rs.next()) {
                    Filmes todosFilmes = new Filmes(
                        rs.getInt("codigo"),
                        rs.getString("nome"),
                        rs.getDouble("duracao"),
                        rs.getString("genero")
                    ); //Busca as informações de todos os filmes coluna por coluna
                    filmes.add(todosFilmes); //Adiciona os filmes ao ArrayList
                }
             } catch (SQLException e) {
                System.out.println("Erro ao obter filmes.");
                e.printStackTrace();
             }

             return filmes; //Retorna o ArrayList
    }

    public Filmes obterFilmePorCodigo(int codigo) {
        String sql = "SELECT * FROM filmes WHERE codigo = ?"; //Comando SQL para buscar todas as informações de um filme específico
        Filmes filmes = null;

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, codigo); //Passa para o banco de dados o código do filme desejado
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    filmes = new Filmes(
                        rs.getInt("codigo"),
                        rs.getString("nome"),
                        rs.getDouble("duracao"),
                        rs.getString("genero")
                    );
                }
             } catch (SQLException e) {
                System.out.println("Erro ao obter filme por código.");
                e.printStackTrace();
             }

             return filmes;
    }

    public void atualizarFilme(Filmes filmes) {
        String sql = "UPDATE filmes SET nome = ?, duracao = ?, genero = ? WHERE codigo = ?"; //Comando SQL para atualizar um filme específico

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, filmes.getNome());
                stmt.setDouble(2, filmes.getDuracao());
                stmt.setString(3, filmes.getGenero());
                stmt.setInt(4, filmes.getCodigo());

                int linhasAfetadas = stmt.executeUpdate();
                if (linhasAfetadas > 0) {
                    System.out.println("Filme atualizado com sucesso!");
                } else {
                    System.out.println("Filme não encontrado.");
                }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar filme.");
            e.printStackTrace();
        }
    }

    public void deletarFilme(int codigo) {
        String sql = "DELETE FROM filmes WHERE codigo = ?"; //Comando SQL para deletar um filme específico

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
                
                stmt.setInt(1, codigo);

                int linhasAfetadas = stmt.executeUpdate();
                if (linhasAfetadas > 0) {
                    System.out.println("Filme deletado com sucesso!");
                } else {
                    System.out.println("Filme não encontrado.");
                }
        } catch (SQLException e) {
            System.out.println("Erro ao deletar filme.");
            e.printStackTrace();
        }
    }
}
