//Idem ao FilmesRepository

package repository;

import models.Usuarios;
import config.DbConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuariosRepository {
    public void adicionarUsuario(Usuarios usuarios){
        String sql = "INSERT INTO usuarios (usuarios, senha, qtdPerfils) VALUES (?, ?, ?)";

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);) {
            
            stmt.setString(1, usuarios.getUsuario());
            stmt.setString(2, usuarios.getSenha());
            stmt.setInt(3, usuarios.getPerfil());

            int linhasAfetadas = stmt.executeUpdate();
            if(linhasAfetadas > 0) {
                System.out.println("Usuario adicionado com sucesso!");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao adicionar usuario.");
            e.printStackTrace();
        }
    }

    public List<Usuarios> obterTodosUsuarios() {
        List<Usuarios> usuarios = new ArrayList<>();
        String sql = "SELECT * FROM usuarios";

        try (Connection conn = DbConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
                
                while (rs.next()) {
                    Usuarios todosUsuarios = new Usuarios(
                        rs.getString("usuarios"),
                        rs.getString("senha"),
                        rs.getInt("qtdPerfils")
                    );
                    usuarios.add(todosUsuarios);
                }
             } catch (SQLException e) {
                System.out.println("Erro ao obter usuarios.");
                e.printStackTrace();
             }

             return usuarios;
    }

    public Usuarios obterUsuarioPorUsuarios(String usuario) {
        String sql = "SELECT * FROM usuarios WHERE usuarios = ?";
        Usuarios usuarioResult = null;
    
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, usuario); 
            ResultSet rs = stmt.executeQuery();
    
            if (rs.next()) {
                usuarioResult = new Usuarios(
                    rs.getString("usuarios"),
                    rs.getString("senha"),
                    rs.getInt("qtdPerfils")
                );
            }
        } catch (SQLException e) {
            System.out.println("Erro ao obter usuario por código.");
            e.printStackTrace();
        }
    
        return usuarioResult;
    }

    public void atualizarUsuario(Usuarios usuarios) {
        String sql = 
            "UPDATE usuarios SET senha = ?, qtdPerfils = ? WHERE usuarios = ?";

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, usuarios.getSenha());
                stmt.setInt(2, usuarios.getPerfil());
                stmt.setString(3, usuarios.getUsuario());

                int linhasAfetadas = stmt.executeUpdate();
                if (linhasAfetadas > 0) {
                    System.out.println("Usuario atualizado com sucesso!");
                } else {
                    System.out.println("Usuario não encontrado.");
                }
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar usuario.");
            e.printStackTrace();
        }
    }

    public void deletarUsuario(String usuario) {
        String sql = "DELETE FROM usuarios WHERE usuarios = ?";

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
                
                stmt.setString(1, usuario);

                int linhasAfetadas = stmt.executeUpdate();
                if (linhasAfetadas > 0) {
                    System.out.println("Usuario deletado com sucesso!");
                } else {
                    System.out.println("Usuario não encontrado.");
                }
        } catch (SQLException e) {
            System.out.println("Erro ao deletar usuario.");
            e.printStackTrace();
        }
    }
}