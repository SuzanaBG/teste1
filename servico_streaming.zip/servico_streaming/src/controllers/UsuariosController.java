//Idem ao FilmesController

package controllers;

import models.Usuarios;
import repository.UsuariosRepository;
import views.Usuarios_Conferir;
import views.Usuarios_Cadastro;

import javax.swing.*;
import java.util.List;

public class UsuariosController {
    private UsuariosRepository repository;
    private Usuarios_Conferir tableView;

    public UsuariosController() {
        repository = new UsuariosRepository();
        tableView = new Usuarios_Conferir(this); 
        inicializar();
    }

    public void inicializar() {
        atualizarTabela();
        tableView.setVisible(true);
    }

    public void atualizarTabela() {
        List<Usuarios> usuarios = repository.obterTodosUsuarios();
        tableView.atualizarTabela(usuarios);
    }

    public void adicionarUsuario() {
        Usuarios_Cadastro cadastro = new Usuarios_Cadastro(tableView, "Adicionar Usuario");
        cadastro.setVisible(true);
        Usuarios novoUsuario = cadastro.getUsuarios();
        if (novoUsuario != null) {
            try {
                repository.adicionarUsuario(novoUsuario);
                atualizarTabela();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(tableView, "Erro ao adicionar usuario: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void editarUsuario() {
        String selectedUsuario = tableView.getSelectedUsuario();  
        if (selectedUsuario != null && !selectedUsuario.isEmpty()) {
            Usuarios usuario = repository.obterUsuarioPorUsuarios(selectedUsuario);  
    
            if (usuario != null) {
                Usuarios_Cadastro cadastro = new Usuarios_Cadastro(tableView, "Editar Usuario", usuario);
                cadastro.setVisible(true);
                Usuarios usuarioAtualizado = cadastro.getUsuarios();
    
                if (usuarioAtualizado != null) {
                    repository.atualizarUsuario(usuarioAtualizado);
                    atualizarTabela();
                }
            } else {
                JOptionPane.showMessageDialog(tableView, "Usuario não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(tableView, "Selecione um usuario para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    public void deletarUsuario() {
        String selectedUsuario = tableView.getSelectedUsuario();
        if (selectedUsuario != null && !selectedUsuario.isEmpty()) {
            int confirm = JOptionPane.showConfirmDialog(
                tableView,
                "Tem certeza que deseja deletar este usuario?",
                "Confirmar deletação",
                JOptionPane.YES_NO_OPTION
            );
            
            if (confirm == JOptionPane.YES_OPTION) {
                repository.deletarUsuario(String.valueOf(selectedUsuario));
                atualizarTabela();
            }
        } else {
            JOptionPane.showMessageDialog(tableView, "Selecione um usuario para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void iniciar(){}
}
