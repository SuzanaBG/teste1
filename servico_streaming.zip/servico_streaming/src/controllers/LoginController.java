package controllers;

import models.LoginModel;
import repository.LoginRepository;
import views.LoginView;
import views.Inicio;

import javax.swing.*;
import java.util.List;
import java.sql.SQLException;

public class LoginController {
    private LoginRepository repository;
    private LoginView loginView;

    public LoginController() {
        repository = new LoginRepository();
        loginView = new LoginView(this);
        inicializar();
    }
    
    public void inicializar() {
        obterLogins();
        loginView.setVisible(true);
    }
    
    public void obterLogins() {
        try {
            List<LoginModel> logins = repository.obterTodosLogins();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao obter logins: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public boolean validarCredenciais(String usuario, String senha) throws SQLException {
        List<LoginModel> logins = repository.obterTodosLogins();
        if (logins == null) {
            return false;
        }
        for (LoginModel login : logins) {
            if (String.valueOf(login.getUsuario()).equals(usuario) && login.getSenha().equals(senha)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean tentarLogin(String usuario, String senha) {
        try {
            if (validarCredenciais(usuario, senha)) {
                System.out.println("Login realizado com sucesso");
                Inicio inicio = new Inicio();
                inicio.setVisible(true);
                return true;
            } else {
                System.out.println("Usuário ou senha inválidos.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao tentar login: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public void iniciar() {}
}