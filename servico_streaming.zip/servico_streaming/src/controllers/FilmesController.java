package controllers;

import models.Filmes;
import repository.FilmesRepository;
import views.Filmes_Conferir;
import views.Filmes_Cadastro;

import javax.swing.*;
import java.util.List;

public class FilmesController {
    private FilmesRepository repository; //Variável repository para chamar as funções do arquivo FilmesRepository
    private Filmes_Conferir tableView;  //Variável para chamar a página Filmes_Conferir

    public FilmesController() {
        repository = new FilmesRepository(); //Cria um novo FilmesRepository()
        tableView = new Filmes_Conferir(this);  //Cria um novo Filmes_Conferir()
        inicializar(); //Chama a função inicializar()
    }

    public void inicializar() {
        atualizarTabela(); //Chama a função atualizarTabela()
        tableView.setVisible(true); //Deixa a tela Filmes_Conferir visível
    }

    public void atualizarTabela() {
        List<Filmes> filmes = repository.obterTodosFilmes(); //Lista todos os filmes do banco de dados apartir da função obterTodosFilmes() do repository
        tableView.atualizarTabela(filmes);
    }

    public void adicionarFilme() {
        Filmes_Cadastro cadastro = new Filmes_Cadastro(tableView, "Adicionar Filme"); //Cria um novo Filmes_Cadastro
        cadastro.setVisible(true); //Deixa a tela Filmes_Cadastro vaisível
        Filmes novoFilme = cadastro.getFilmes(); //Chama os valores inseridos em Filmes_Cadastro através da função getFilmes()
        if (novoFilme != null) {
            try {
                repository.adicionarFilme(novoFilme); //Passa os valores inseridos em Filmes_Cadastro para a funçao adicionarFilme no repository
                atualizarTabela();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(tableView, "Erro ao adicionar filme: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void editarFilme() {
        int selectedCodigo = tableView.getSelectedFilmeCodigo(); //Chama o filme selecionado através da função getSelectedFilmeCodigo() de Filmes_Conferir
        if (selectedCodigo != -1) {
            Filmes filmes = repository.obterFilmePorCodigo(selectedCodigo); //Passa o código do filme selecionado para a função obterFilmePorCodigo() no repository
            if (filmes != null) {
                Filmes_Cadastro cadastro = new Filmes_Cadastro(tableView, "Editar Filme", filmes);
                cadastro.setVisible(true);
                Filmes filmeAtualizado = cadastro.getFilmes();
                if (filmeAtualizado != null) {
                    filmeAtualizado = new Filmes(
                        selectedCodigo,
                        filmeAtualizado.getNome(),
                        filmeAtualizado.getDuracao(),
                        filmeAtualizado.getGenero()
                    ); //Passa os valores inseridos em Filmes_Cadastro para o model
                    repository.atualizarFilme(filmeAtualizado); //Passa os valores para para a função atualizarFilme() no repository
                    atualizarTabela();
                }
            } else {
                JOptionPane.showMessageDialog(tableView, "Filme não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(tableView, "Selecione um filme para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void deletarFilme() {
        int selectedCodigo = tableView.getSelectedFilmeCodigo();
        if (selectedCodigo != -1) {
            int confirm = JOptionPane.showConfirmDialog(
                tableView,
                "Tem certeza que deseja deletar este filme?",
                "Confirmar deletação",
                JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                repository.deletarFilme(selectedCodigo); //Passa o código do filme selecionado para a função deletarFilme() no repository
                atualizarTabela();
            }
        } else {
            JOptionPane.showMessageDialog(tableView, "Selecione um filme para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void iniciar(){}
}