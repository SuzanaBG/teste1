package controllers;

import models.Series;
import repository.SeriesRepository;
import views.Series_Conferir;
import views.Series_Cadastro;

import javax.swing.*;
import java.util.List;

public class SeriesController {
    private SeriesRepository repository;
    private Series_Conferir tableView;

    public SeriesController() {
        repository = new SeriesRepository();
        tableView = new Series_Conferir(this); 
        inicializar();
    }

    public void inicializar() {
        atualizarTabela();
        tableView.setVisible(true);
    }

    public void atualizarTabela() {
        List<Series> series = repository.obterTodosSeries();
        tableView.atualizarTabela(series);
    }

    public void adicionarSerie() {
        Series_Cadastro cadastro = new Series_Cadastro(tableView, "Adicionar Serie");
        cadastro.setVisible(true);
        Series novoSerie = cadastro.getSeries();
        if (novoSerie != null) {
            try {
                repository.adicionarSerie(novoSerie);
                atualizarTabela();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(tableView, "Erro ao adicionar serie: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void editarSerie() {
        int selectedCodigo = tableView.getSelectedSerieCodigo();
        if (selectedCodigo != -1) {
            Series series = repository.obterSeriePorCodigo(selectedCodigo);
            if (series != null) {
                Series_Cadastro cadastro = new Series_Cadastro(tableView, "Editar Serie", series);
                cadastro.setVisible(true);
                Series serieAtualizado = cadastro.getSeries();
                if (serieAtualizado != null) {
                    serieAtualizado = new Series(
                        selectedCodigo,
                        serieAtualizado.getNome(),
                        serieAtualizado.getDuracao(),
                        serieAtualizado.getQtdEp(),
                        serieAtualizado.getQtdTemp(),
                        serieAtualizado.getGenero()
                    );
                    repository.atualizarSerie(serieAtualizado);
                    atualizarTabela();
                }
            } else {
                JOptionPane.showMessageDialog(tableView, "Serie não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(tableView, "Selecione um serie para editar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void deletarSerie() {
        int selectedCodigo = tableView.getSelectedSerieCodigo();
        if (selectedCodigo != -1) {
            int confirm = JOptionPane.showConfirmDialog(
                tableView,
                "Tem certeza que deseja deletar este serie?",
                "Confirmar deletação",
                JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                repository.deletarSerie(selectedCodigo);
                atualizarTabela();
            }
        } else {
            JOptionPane.showMessageDialog(tableView, "Selecione um serie para deletar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void iniciar(){}
}
