package models;

public class Series {
    private int codigo;
    private String nome;
    private double duracao;
    private int qtdEp;
    private int qtdTemp;
    private String genero;

    public Series() {}

    public Series(int codigo, String nome, double duracao, int qtdEp, int qtdTemp, String genero) {
        this.codigo = codigo;
        this.nome = nome;
        this.duracao = duracao;
        this.qtdEp = qtdEp;
        this.qtdTemp = qtdTemp;
        this.genero = genero;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome(){
        return nome;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public double getDuracao(){
        return duracao;
    }

    public void setDuracao(double duracao){
        this.duracao = duracao;
    }

    public int getQtdEp() {
        return qtdEp;
    }

    public void setQtdEp (int qtdEp) {
        this.qtdEp = qtdEp;
    }

    public int getQtdTemp() {
        return qtdTemp;
    }

    public void setQtdTemp (int qtdTemp) {
        this.qtdTemp = qtdTemp;
    }

    public String getGenero(){
        return genero;
    }

    public void setGenero(String genero){
        this.genero = genero;
    }

    @Override
    public String toString(){
        return "Série [código= " + codigo + ", nome= " + nome + ", duração= " + duracao + ", quantidade de episódios= " + qtdEp + ", quantidade de temporadas= " + qtdTemp + ", gênero= " + genero + "]";
    }
}