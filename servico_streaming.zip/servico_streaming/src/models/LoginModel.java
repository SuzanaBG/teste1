package models;

public class LoginModel {
    private int usuario;
    private String senha;

    public LoginModel() {}

    public LoginModel (int usuario, String senha) {
        this.usuario = usuario;
        this.senha = senha;
    }

    public int getUsuario() {
        return usuario;
    }

    public void setUsuario (int usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha (String senha) {
        this.senha = senha;
    }

    @Override
    public String toString(){
        return "Login [Usuário= " + usuario + ", senha= " + senha + "]";
    }
}
