package models;

public class Filmes {
    private int codigo;
    private String nome;
    private double duracao;
    private String genero;

    public Filmes(){}

    public Filmes(int codigo, String nome, double duracao, String genero) {
        this.codigo = codigo;
        this.nome = nome;
        this.duracao = duracao;
        this.genero = genero;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome(){
        return nome;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public double getDuracao(){
        return duracao;
    }

    public void setDuracao(double duracao){
        this.duracao = duracao;
    }

    public String getGenero(){
        return genero;
    }

    public void setGenero(String genero){
        this.genero = genero;
    }

    @Override
    public String toString(){
        return "Filme [código= " + codigo + ", nome= " + nome + ", Duração= " + duracao + ", Gênero= " + genero + "]";
    }
}
