package models;

public class Usuarios{
    private String usuario, senha;
    private int perfil;

    public Usuarios(){}

    public Usuarios(String usuario, String senha, int perfil){
        this.usuario = usuario;
        this.senha = senha;
        this.perfil = perfil;
    }

    public String getUsuario(){
        return usuario;
    }

    public void setUsuario(String usuario){
        this.usuario = usuario;
    }

    public String getSenha(){
        return senha;
    }

    public void setSenha(String senha){
        this.senha = senha;
    }

    public int getPerfil(){
        return perfil;
    }

    public void setPerfil(int perfil){
        this.perfil = perfil;
    }

    @Override
    public String toString(){
        return "Usuário [Usuário= " + usuario + ", Senha= " + senha + ", Quantidade de perfils= " + perfil + "]";
    }
}